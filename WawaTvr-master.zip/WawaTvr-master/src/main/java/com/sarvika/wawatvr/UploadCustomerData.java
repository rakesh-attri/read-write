package com.sarvika.wawatvr;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class UploadCustomerData {
	
	  // WebDriver object
	  static WebDriver driver;
	  static long timeOutInSeconds = 60; //1 minute
	  static long timeOutInSecondsImportToDownload = 72000; //1200 minute = 20 hour
	  String winHandleBefore = "";
	
	public void processData() {
		
		java.util.Date startDateTime = Util.getDateTime(); // to get datetime when script started
		
		// Opening browser
		invokeBrowser();
		
		// Login
		login();
		
		// Search Store
		searchStore();
		
	    try {
	        Thread.sleep(5000);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }		
	    
		// Open Store
		openStore();
		
	    try {
	        Thread.sleep(5000);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }	
	    
		// Open Customers URL
		openCustomers();
		
	    try {
	        Thread.sleep(5000);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }	
	    
		// Click on Impot button to expand show options
		openExpandToImport();
		
		// Click on import to show options to select
		openImportOptions();
		
		// Open browse to import
		openBrowseToImport();
		
		// Upload file to import
		uploadFileToImport();
		
	    try {
	        Thread.sleep(2000);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }	
		
		// Final import to shopstar
		finalImportToShopstart();
		
	    try {
	        Thread.sleep(2000);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }	
	    
	    // verify import done and send mail
	    verifyImportDone();
	    
	    try {
	        Thread.sleep(5000);
	      } catch (InterruptedException e) {
	        e.printStackTrace();
	      }	
		
		// Logout
		logout();
		
		java.util.Date endDateTime = Util.getDateTime(); // to get datetime when script ended
		System.out.println("UploadCustomerData time taken:");
		Util.showTimeDifference(startDateTime, endDateTime);
		
	}

	 public void invokeBrowser() {
		    try {
		      System.out.println("Opening Browser");
		      
		      if (Util.isWindows()) {
		          System.out.println("This is Windows");
		          System.setProperty("webdriver.gecko.driver", "gecodriver/geckodriver.exe");
		      } else if (Util.isMac()) {
		          System.out.println("This is Mac");
		          System.setProperty("webdriver.gecko.driver", "gecodrivermac/geckodriver");
		      } else if (Util.isUnix()) {
		          System.out.println("This is Unix or Linux");
		          System.setProperty("webdriver.gecko.driver", "gecodriver/geckodriver");
		      } else if (Util.isSolaris()) {
		          System.out.println("This is Solaris");
		          System.setProperty("webdriver.gecko.driver", "gecodriver/geckodriver");
		      } else {
		          System.out.println("Your OS is not support!!");
		      }
		      
		      if(Constants.isDisableFirefoxLog) { // To disable firefox log
		          System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE,"true");
		          if (Util.isUnix()) {
		        	  System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE,"//home//gitlab-runner//exceldata//logs.txt");
		          }else if (Util.isWindows()) {
		        	  System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE,"exceldata//logs.txt");
		          }else {
		        	  System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE,"exceldata//logs.txt");
		          }
		      }
		      
		      if(Constants.isHeadlessRequired){ // to enable headless or not
		          FirefoxBinary firefoxBinary = new FirefoxBinary();
		          firefoxBinary.addCommandLineOptions("--headless");
		          FirefoxOptions firefoxOptions = new FirefoxOptions();
		          //firefoxOptions.setLogLevel(FirefoxDriverLogLevel.TRACE);
		          firefoxOptions.setBinary(firefoxBinary);
		          driver = new FirefoxDriver(firefoxOptions);
		          driver.manage().deleteAllCookies();
		          driver.manage().window().maximize();
		          System.out.println("You are running in headless mode");
		      }else{
		    	  driver = new FirefoxDriver();
		          driver.manage().deleteAllCookies();
		          driver.manage().window().maximize();
		          System.out.println("You are not running in headless mode");
		      }
		      
		      driver.manage().timeouts().implicitlyWait(timeOutInSeconds, TimeUnit.SECONDS);
		      driver.manage().timeouts().pageLoadTimeout(timeOutInSeconds, TimeUnit.SECONDS);
		      
		      System.out.println("[Calling URL  ]---> " + Constants.SERVER_URL);
		      driver.get(Constants.SERVER_URL); // opening the browser with give url
		    } catch (Exception e) {
		      String STRING1 = "Exception occured in invokeBrowser";
		      System.out.println(STRING1);
		      e.printStackTrace();
		      driver.quit();
		      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
		      System.out.println(STRING2);
		      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
		      System.exit(1);
		    }
		  }
	 
		  public void login() {
			    try {
			      System.out.println("loginToSystem called");
			      
			      WebDriverWait waitLogin = new WebDriverWait(driver, timeOutInSeconds);
			      waitLogin.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div[1]/form/div[3]/input"))); // //input[@class='btn btn-info btn-block']
	
			      WebElement email = driver.findElement(By.name("j_username"));
			      WebElement password = driver.findElement(By.name("j_password"));
	
			      email.sendKeys(Constants.USER_NAME);
			      password.sendKeys(Constants.USER_PASS);
	
			      WebElement loginBtn = driver.findElement(By.xpath("/html/body/div/div[1]/form/div[3]/input")); //  //input[@class='btn btn-info btn-block']
	
			      loginBtn.click();
	
			    } catch (Exception e) {
			    	String STRING1 = "Exception occured in login";
			        System.out.println(STRING1);
			        e.printStackTrace();
			        driver.quit();
			        String STRING2 = "\nTerminating Current Program due to: " + e.getLocalizedMessage();
			        System.out.println(STRING2);
			        SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
			        System.exit(1);
			    }
		  }
		  
		  public void searchStore() {
			    try {
			        System.out.println("Searching store called");
			        
			        WebElement searchElement = driver.findElement(By.xpath("//input[@id='quick_search_box']"));
			        searchElement.sendKeys(Constants.VID);
			        driver.findElement(By.xpath("//form[@name='shopstar_search_form']//input[@class='btn btn-primary']")).click();
			        
			      } catch (Exception e) {
			    	  String STRING1 = "Exception occured in searchStore";
			          System.out.println(STRING1);
			          e.printStackTrace();
			          driver.quit();
			          String STRING2 = "\nTerminating Current Program due to: " + e.getLocalizedMessage();
			          System.out.println(STRING2);
			          SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
			          System.exit(1);
			      }
		  }
		  
		  public void openStore() {
			  
			winHandleBefore = driver.getWindowHandle();
//			driver.findElement(By.xpath("//a[contains(text(),'20190701479')]")).click();
			driver.findElement(By.xpath("//a[contains(text(),'" + Constants.VID + "')]")).click();
			
		    try {
		        Thread.sleep(2000);
		      } catch (InterruptedException e) {
		        e.printStackTrace();
		      }		
			  
			for(String winHandle : driver.getWindowHandles()){
		           driver.switchTo().window(winHandle);            
		    } 
			  
			String openUrl = Constants.OPEN_VID_URL_PREFIX + Constants.VID + Constants.OPEN_VID_URL_SUFFIX; //"https://qa.mypromomall.com/preview/viewcustomers.admin?ppg=managepeople.admin&vid=20190701479";
			  
			try {  
		      System.out.println("[Opening vendorid URL  ]---> " + openUrl);
		      driver.get(openUrl); // opening the browser with give url
		      
//			    try {
//			        Thread.sleep(3000);
//			      } catch (InterruptedException e) {
//			        e.printStackTrace();
//			      }			      
//		      
//		      Util.scrollDownPage(driver); // scroll the page till end
		      
		    } catch (Exception e) {
		      String STRING1 = "Exception occured in openStore";
		      System.out.println(STRING1);
		      e.printStackTrace();
		      driver.quit();
		      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
		      System.out.println(STRING2);
		      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
		      System.exit(1);
		    }				  
		  }
		  
		  public void openCustomers() {
//			  https://qa.mypromomall.com/preview/viewcustomers.admin?ppg=managepeople.admin&vid=20190701479
			  String openUrl = Constants.OPEN_CUSTOMERS_URL + Constants.VID;
				try {  
				      System.out.println("[Opening openCustomers URL  ]---> " + openUrl);
				      driver.get(openUrl); // opening the browser with give url
				      
					    try {
					        Thread.sleep(3000);
					      } catch (InterruptedException e) {
					        e.printStackTrace();
					      }			      
				      
				      Util.scrollDownPage(driver); // scroll the page till end
				      
				    } catch (Exception e) {
				      String STRING1 = "Exception occured in openCustomers";
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				    }	
		  }
		  
		  public void openExpandToImport() {
			
				try {  
					
					  WebElement webElementImprtIcon = driver.findElement(By.xpath("//div[@class='portlet-title']//a[2]"));
					
					  WebDriverWait waitLogin = new WebDriverWait(driver, timeOutInSeconds);
				      waitLogin.until(ExpectedConditions.elementToBeClickable(webElementImprtIcon));
					
				      System.out.println("openExpandToImport called ");
				      webElementImprtIcon.click(); // Click on expand icon to see import option
				    } catch (Exception e) {
				      String STRING1 = "Exception occured in openExpandToImport";
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				 }	
		  }
		  
		  public void openImportOptions() {
				
				try {  
				      System.out.println("openImportOptions called ");
				      driver.findElement(By.xpath("//input[@name='_import']")).click(); // Click on import button to see import option
				    } catch (Exception e) {
				      String STRING1 = "Exception occured in openImportOptions";
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				 }	
		  }
		  
		  public void openBrowseToImport() {
				
				try {  
					System.out.println("openBrowseToImport called ");
					
					WebElement webElementUploadFile= driver.findElement(By.xpath("//input[@id='upfile']"));
					
					//To wait for element visible
					  WebDriverWait wait = new WebDriverWait(driver, 20);
					  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='upfile']")));
					
				      if(webElementUploadFile.isDisplayed()) {
				    	  System.out.println("webElementUploadFile displayed ");
				      
				    	  WebElement uploadElement = driver.findElement(By.id("upfile"));
				    	  // enter the file path onto the file-selection input field
				    	  String projectRootPath = Util.getProjectDirectory();
				    	  if(Util.isWindows()) {
				    		  uploadElement.sendKeys(projectRootPath + "\\" + Constants.FILE_PATH_EXCEL + "\\" + Constants.FILE_NAME_WRITE_EXCEL_XLS);
				    	  }else {
				    		  uploadElement.sendKeys(projectRootPath + "/" + Constants.FILE_PATH_EXCEL + "/" + Constants.FILE_NAME_WRITE_EXCEL_XLS);	  
				    	  }
				      }
				      
				      
				    } catch (Exception e) {
				      String STRING1 = "Exception occured in openBrowseToImport";
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				 }	
		  }
		  
		  public void uploadFileToImport() {
				
				try {  
				      System.out.println("uploadFileToImport called ");
				      
				      // click the "Import" button
				      openImportOptions();
				      
				    } catch (Exception e) {
				      String STRING1 = "Exception occured in uploadFileToImport";
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 =  "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				 }	
		  }		  
		  
		  public void finalImportToShopstart() {
				
				try {  
				      System.out.println("finalImportToShopstart called ");
				      
				      // this will take the last import link in row list
						WebElement webElementImportLink= driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[7]/a[2]")); // - //tr[@class='odd']//b[contains(text(),'import')]
						
						//To wait for element visible
						  WebDriverWait wait = new WebDriverWait(driver, 20);
						  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[7]/a[2]")));
						
					      if(webElementImportLink.isDisplayed()) {
					    	  System.out.println("webElementImportLink displayed ");
					    	  String strImport = webElementImportLink.getText();
					    	  System.out.println("webElementImportLink text: " + strImport);
					    	  if(strImport.equalsIgnoreCase("import") ) {
					    		  System.out.println("Before webElementImportLink click");
					    		  webElementImportLink.click();
					    		  System.out.println("After webElementImportLink click");
					    	  }
					      }				    
				      
				    } catch (Exception e) {
				      String STRING1 = "Exception occured in finalImportToShopstart";
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				 }	
		  }	
		  
		  //setTimeout("autoRefresh()",60000); - This applied on page for autoreferesh so thread will sleep for 20 seconds after check
		  
		  public void verifyImportDone() {
			  
				try {
						System.out.println("verifyImportDone called ");
						
						java.util.Date importStartDateTime = Util.getDateTime();
						String strImportStartDateTime = "Import/Inject starting into database at: " + importStartDateTime;
						System.out.println(strImportStartDateTime);
						SendMailSSLWithMessage.sendEmailWithMessage(strImportStartDateTime);
						
						
						
						driver.manage().timeouts().implicitlyWait(timeOutInSecondsImportToDownload, TimeUnit.SECONDS);
						
						
//						WebElement webElementImporStatusLink= driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[6]"));  // Status - Success / Error
//						
//						//To wait for element Import status visible
//						  WebDriverWait wait = new WebDriverWait(driver, 36000);
//						  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[6]"))); // Success
						  
						  WebElement webElementDownloadLink= driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[7]/a[2]"));  // download  
						  
						//To wait for element download link visible
						  WebDriverWait waitDownloadLink = new WebDriverWait(driver, timeOutInSecondsImportToDownload);
						  waitDownloadLink.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[7]/a[2]"))); // download
						  
						  if(webElementDownloadLink.isDisplayed()) {
					
					      // this will take the last import link in row list
							WebElement webElementDownloadtLink= driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[7]/a[2]")); // download
							WebElement webElementSuccessLink= driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div[2]/div/div/form/table/tbody/tr[1]/td[6]")); // Success
							
						      if(webElementDownloadtLink.isDisplayed()) {
						    	  System.out.println("webElementDownloadtLink displayed ");
						    	  
						    	  java.util.Date importEndDateTime = Util.getDateTime();
								  String strImportEndDateTime = "Import/Inject ended into database at: " + importEndDateTime;
								  System.out.println(strImportEndDateTime);
								  SendMailSSLWithMessage.sendEmailWithMessage(strImportEndDateTime);
						    	  
						    	  String strDownload = webElementDownloadtLink.getText();
						    	  String strStatus = webElementSuccessLink.getText();
						    	  System.out.println("webElementDownloadtLink text: " + strDownload);
						    	  System.out.println("webElementSuccessLink text: " + strStatus);
						    	  if(strDownload.equalsIgnoreCase("download") && strStatus.equalsIgnoreCase("Success")) {
						    		  //TODO: Send email that user imported successfully
						    		  System.out.println("Download link displayed and ready to send email of success");
						    		  SendMailSSLWithMessage.sendEmailWithMessage("Wawa TVR Customers data uploaded successfully into ShopSTAR.");
						    	  }else {
						    		  System.out.println("Download link or Status not displayed");
						    		  SendMailSSLWithMessage.sendEmailWithMessage("Some problem while importing due to Download link or Status not displayed");
						    	  }
						      }	
						  }else {
							  System.out.println("Status not displayed");
				    		  SendMailSSLWithMessage.sendEmailWithMessage("Some problem while importing due to Status not displayed");
						  }
				      
				    } catch (Exception e) {
				     String STRING1 = "Exception occured in verifyImportDone at: " + Util.getDateTime();
				      System.out.println(STRING1);
				      e.printStackTrace();
				      driver.quit();
				      String STRING2 = "\nTerminating/Exception Current Program due to: " + e.getLocalizedMessage();
				      System.out.println(STRING2);
				      SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
				      System.exit(1);
				 }
			  
		  }
		  
		  public void logout() {
			  
			    try {
			        System.out.println("logout called");
			        
			        // New page logout
			      // ----- //i[@class='fa fa-sign-out']
			      // -----  /html/body/div[1]/div[2]/div[4]/span/a/i
			        
			        driver.close();
					driver.switchTo().window(winHandleBefore); 
					
				    try {
				        Thread.sleep(5000);
				      } catch (InterruptedException e) {
				        e.printStackTrace();
				      }	
			        
			        driver.findElement(By.xpath("//a[contains(text(),'Log Out')]")).click();

			      } catch (Exception e) {
			    	  String STRING1 = "Exception occured in logout";
			          System.out.println(STRING1);
			          e.printStackTrace();
			          driver.quit();
			          String STRING2 = "\nTerminating Current Program due to: " + e.getLocalizedMessage();
			          System.out.println(STRING2);
			          SendMailSSLWithMessage.sendEmailWithMessage(STRING1 + STRING2);
			          System.exit(1);
			      }
			  
			    System.out.println("\nClosing browser");

			    try {
			      Thread.sleep(8000);
			    } catch (InterruptedException e) {
			      e.printStackTrace();
			    }
			    driver.quit();
		  }
	 
}
