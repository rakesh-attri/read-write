package com.sarvika.wawatvr;

import java.io.File;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

/*
 * Helper class to provide all utility functions
 */
public class Util {
	
	static HashMap<String, String> shopperGroups = new HashMap<String, String>();
	
	/*
	 * To get current Date time
	 */
	public static java.util.Date getDateTime(){
		java.util.Date scriptDate = new java.util.Date();  
		return scriptDate;
	}
	
	/*
	 * Time Zone dependent to getLocalDate
	 */
	  public static String getLocalDate(String format){
		  	Date date = new Date();
//		  	System.out.println("Default Server Date Time: "+ date.toString());
//		  	String format = "yyyy-MM-dd";
		  	String timeZone = "IST"; // PST // GMT // IST // UTC
		  	// create SimpleDateFormat object with input format
		 	SimpleDateFormat sdf = new SimpleDateFormat(format);
		 	// set timezone to SimpleDateFormat
		 	sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		 	String ldtString = sdf.format(date);
//		 	System.out.println("Local Date Time in " + timeZone +  " : " + ldtString);
		 	return ldtString;
	  }
	  
	  /*
	   * Time Zone dependent to getDOB
	   */
	  public static String getDOB(String strDate){
		  	Date date = new Date();
		  	String ldtString = "";
//		  	System.out.println("Default Server Date Time: "+ date.toString());
		  	String format = "dd-MMM-yyyy";
		  	String timeZone = "IST"; // PST // GMT // IST // UTC
		  	// create SimpleDateFormat object with input format
		 	SimpleDateFormat sdf = new SimpleDateFormat(format);
		 	// set timezone to SimpleDateFormat
		 	sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		 	try {
				date = sdf.parse(strDate);
			 	String formatNew = "yyyy-MM-dd";
			 	SimpleDateFormat sdfnew = new SimpleDateFormat(formatNew);
			 	ldtString = sdfnew.format(date);
//			 	System.out.println("Local Date Time in " + timeZone +  " : " + ldtString);				
			} catch (ParseException e) {
				e.printStackTrace();
				ldtString = "";
			}
		 	return ldtString;
	  }
	  
	  /*
	   * As per following BRD 13 Shopper Group taken - https://halobrandedsolutions.atlassian.net/wiki/spaces/NSS/pages/1106542740/Wawa+Uniform+Store+BRD 
	   */
		public static void fillShopperGroupList() {
			// Add hard code shopper group keys and values like (Customer Service Associate, ASSOCIATES)
		    shopperGroups.put("Customer Service Associate", "ASSOCIATES"); // (CSA)
		    shopperGroups.put("Lead Customer Service Associate", "ASSOCIATES"); // (LCSA)
		    
		    shopperGroups.put("Customer Service Supervisor", "SUPERVISORS"); // (CSS)
		    shopperGroups.put("Food & Beverage Supervisor", "SUPERVISORS"); // (FBS)
		    shopperGroups.put("Night Supervisor", "SUPERVISORS"); // (NS)
		    
		    shopperGroups.put("Food & Beverage Manager", "FB MANAGER"); // (FBM)
		    
		    shopperGroups.put("General Manager", "MANAGERS"); // (GM)
		    shopperGroups.put("General Manager In Training", "MANAGERS"); // (GMIT)
		    shopperGroups.put("Assistant General Manager", "MANAGERS"); // (AGM)
		    
		    shopperGroups.put("Fuel Associate", "FUEL ASSOCIATES"); // (FA)
		    
		    shopperGroups.put("New Jersey General Manager", "NJ MANAGERS"); // (GM)
		    shopperGroups.put("New Jersey General Manager in Training", "NJ MANAGERS"); // (GMIT)
		    shopperGroups.put("New Jersey Assistant General Manager", "NJ MANAGERS"); // (AGM)
		}
		
	  	/*
	  	 * To get required shopper group in shop star
	  	 */
		public static String getReadableShopperGroup(String receiveShopperGroup) {
			String shopperGroup = "";
			if(receiveShopperGroup.isEmpty()) {
				shopperGroup = "";
			}else {
				if(receiveShopperGroup.contains("(")) {
					int beginIndex = receiveShopperGroup.indexOf(" ");
					int endIndex = receiveShopperGroup.indexOf("(");
					shopperGroup = receiveShopperGroup.substring(beginIndex + 1, endIndex);
				}else {
					int beginIndex = receiveShopperGroup.indexOf(" ");
					shopperGroup = receiveShopperGroup.substring(beginIndex + 1);
				}
//				System.out.println(shopperGroup);
				shopperGroup = getShopperGroupValue(shopperGroup.trim());
//				System.out.println(shopperGroup.trim());
			}
			
			return shopperGroup.trim();
		}		
		
		/*
		 * To get shopper value by providing job title
		 */
		public static String getShopperGroupValue(String jobTitle) {
			String shopperGroup = "";
			if(shopperGroups.get(jobTitle) != null){
				shopperGroup = shopperGroups.get(jobTitle);
			}else {
				shopperGroup = "";
			}
			return shopperGroup;
		}	  
		
		/*
		 * To show home much time takes to process this script
		 */
		public static void showTimeDifference(java.util.Date startDateTime, java.util.Date endDateTime) {
			
			System.out.println("\nScript Start at: " + startDateTime);
			System.out.println("Script End at: " + endDateTime);
			
			DecimalFormat crunchifyFormatter = new DecimalFormat("###,###");
			 
			// getTime() returns the number of milliseconds since January 1, 1970, 00:00:00 GMT represented by this Date object
			long diff = endDateTime.getTime() - startDateTime.getTime();

			int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
			System.out.println("difference between days: " + diffDays);

			int diffhours = (int) (diff / (60 * 60 * 1000));
			System.out.println("difference between hours: " + crunchifyFormatter.format(diffhours));

			int diffmin = (int) (diff / (60 * 1000));
			System.out.println("difference between minutues: " + crunchifyFormatter.format(diffmin));

			int diffsec = (int) (diff / (1000));
			System.out.println("difference between seconds: " + crunchifyFormatter.format(diffsec));

			System.out.println("difference between milliseconds: " + crunchifyFormatter.format(diff));
		}
		
		/*
		 * deleteRow method will delete all rows by passed sheet
		 */
		public static void deleteRow(Sheet sheet, Row row) {
	        int lastRowNum = sheet.getLastRowNum();     
	        if(lastRowNum !=0 && lastRowNum >0){
	            int rowIndex = row.getRowNum();
	            Row removingRow = sheet.getRow(rowIndex);
	            if(removingRow != null){
	                sheet.removeRow(removingRow);
//	                 System.out.println("Deleting in " + sheet.getSheetName() + " sheet row: " + rowIndex);
	            }    
		    }
		}
		
		// To detect which OS is running
		  public static boolean isWindows() {
		      return Constants.OS.contains("win");
		  }

		  public static boolean isMac() {
		      return Constants.OS.contains("mac");
		  }

		  public static boolean isUnix() {
		      return (Constants.OS.contains("nix") || Constants.OS.contains("nux") || Constants.OS.contains("aix"));
		  }

		  public static boolean isSolaris() {
		      return Constants.OS.contains("sunos");
		  }
		  
		public static void scrollDownPage(WebDriver driver) {
			System.out.println("scrollDownPage called");
			JavascriptExecutor js = (JavascriptExecutor) driver;
		    //This will scroll the web page till end.		
		    js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}
		
		public static String getProjectDirectory() {
			String projectRootPath = System.getProperty("user.dir");
			return projectRootPath;
		}
		
		/*
		 * To get home much time takes to process this script in string
		 */
		public static String showTimeDifferenceInString(java.util.Date startDateTime, java.util.Date endDateTime, String message) {
			
			String receiveMsg = "\n" + message;
			
			String timeDiffStr = "";
			
			String strStartDate = "\nStart at: " + startDateTime;
			String strEndDate = "\nEnd at: " + endDateTime;
			
			DecimalFormat crunchifyFormatter = new DecimalFormat("###,###");
			 
			// getTime() returns the number of milliseconds since January 1, 1970, 00:00:00 GMT represented by this Date object
			long diff = endDateTime.getTime() - startDateTime.getTime();

			int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
			String strDaysDiff = "\ndifference between days: " + diffDays;

			int diffhours = (int) (diff / (60 * 60 * 1000));
			String strHoursDiff = "\ndifference between hours: " + crunchifyFormatter.format(diffhours);

			int diffmin = (int) (diff / (60 * 1000));
			String strMinuteDiff = "\ndifference between minutues: " + crunchifyFormatter.format(diffmin);

			int diffsec = (int) (diff / (1000));
			String strSecondsDiff = "\ndifference between seconds: " + crunchifyFormatter.format(diffsec);

			String strMiliSecondsDiff = "\ndifference between milliseconds: " + crunchifyFormatter.format(diff);
			
			timeDiffStr = receiveMsg + strStartDate + strEndDate + strDaysDiff + strHoursDiff + strMinuteDiff + strSecondsDiff + strMiliSecondsDiff;
			
			return timeDiffStr;
		}		
		
		public static void println(String strMsg) {
			if(!Constants.isProduction) {
//				System.out.println(strMsg);
			}
			
		}
			
		/**
		 * To check that file exist on given path
		 * @param filePath
		 * @return boolean
		 */
		public static boolean isFileExist(String filePath) {
			boolean isFilePresent = false;
			 // Get the file 
	        File file = new File(filePath); 
	        
	        // Check if the specified file 
	        // Exists or not 
	        if (file.exists()) {
	            System.out.println("Exists File: " + file.getName()); 
	        	isFilePresent = true;
	        }
	        else {
	            System.out.println("Does not Exists File: " + file.getName());
	        	isFilePresent = false;
	        }
	        return isFilePresent;
		}
		
		/**
		 * To delete file on given path
		 * @param filePath
		 */
		public static void deleteFile(String filePath) {
			File file = new File(filePath);
			boolean isFileDeleted = false;
    		try {
    			isFileDeleted = file.delete();
		      } catch (Exception e) {
		    	isFileDeleted = false;
		        e.printStackTrace();
		        System.out.println(e.getLocalizedMessage());
		      }	
	        
	        if(isFileDeleted) 
	        { 
	            System.out.println("File deleted successfully: " + file.getName()); 
	        } 
	        else
	        { 
	            System.out.println("Failed to delete the file. Might be deleted already.: " + file.getName()); 
	        } 
		}
			
}
