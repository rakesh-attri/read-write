package com.sarvika.wawatvr;

public class Constants {
	
	// Reading file constant
	public static final String FILE_PATH_EXCEL = "exceldata";
	public static final String FILE_NAME_READ_EXCEL = "WAW9_TVRdata.xlsx";
	public static final int FILE_SHEET_INDEX_READ_EXCEL = 0;
	public static final String EMPTY_STRING = "";
	public static final String FILE_NAME_WRITE_EXCEL_XLSX = "Customers.xlsx";
	public static final String FILE_NAME_WRITE_EXCEL_XLS = "Customers.xls";
	public static final String FILE_SHEET_NAME_WRITE_EXCEL_CUSTOMERS = "Customers";
	public static final String FILE_SHEET_NAME_WRITE_EXCEL_PROPERTIES = "Properties";
	public static final boolean IS_XLS_FILE = true;
	public static final String DATE_FORMATE1 = "yyyy-MM-dd";
	public static final String DATE_FORMATE2 = "yyyy-MM-dd HH:mm:ss";
	
	// General
	public static String OS = System.getProperty("os.name").toLowerCase();
	public static boolean isDisableFirefoxLog = true; // If this is true then will now show firefox logs otherwise will show.
	public static boolean isHeadlessRequired = true; // Please true if headless is required
	public static boolean isProduction = false;
	
	// ShopStar
	public static final String USER_NAME = isProduction == true ? "sarvika_bot_prod" : "sarvika_bot"; //sarvika_bot //dkhandal
	public static final String USER_PASS = isProduction == true ? "halo12345" : "halo12345"; //halo12345  //deepak12345
	
	public static final String URL = isProduction == true ? "https://www.mypromomall.com/" : "https://qa.mypromomall.com/preview/";
	public static final String SERVER_URL =  URL + "login.admin";
	public static final String VID = "20190701479";
//	public static final String STORE_URL = SERVER_URL + VID;
	public static final String OPEN_VID_URL_PREFIX = URL + "vendormain.admin?vid=";
	public static final String OPEN_VID_URL_SUFFIX = "&ppg=vieworders.admin";
	public static final String OPEN_CUSTOMERS_URL = URL + "viewcustomers.admin?ppg=managepeople.admin&vid=";
	
}
