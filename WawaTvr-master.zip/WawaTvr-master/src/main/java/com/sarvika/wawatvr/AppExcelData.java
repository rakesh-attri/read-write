package com.sarvika.wawatvr;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Program to Read and Write excel files
 * 
 */
public class AppExcelData 
{
	private Workbook readWorkbook;
	private Workbook writeWorkbook;
	
	// Customer and Properties array list initialization
	ArrayList<String> customerList = new ArrayList<String>();
	ArrayList<String> propertiesList = new ArrayList<String>();
	ArrayList<String> cellValue = new ArrayList<String>();
	
	// Static Properties values
	String[] propName = {"allowance_updated", "allowance_usable", "store_number", "birthday", "allowance_reset_date", "province_id"};
	
	/*
	 * readExcel function to read data from sheet index 
	 */
	public void readExcel(String filePath,String fileName,int sheetIndex) throws IOException{

	    //Create an object of File class to open xlsx file
	    File file =    new File(filePath+"//"+fileName);

	    //Create an object of FileInputStream class to read excel file
	    FileInputStream inputStream = new FileInputStream(file);
	    readWorkbook = new XSSFWorkbook(inputStream);

	    //Read sheet inside the workbook by its index
	    Sheet sheet = readWorkbook.getSheetAt(sheetIndex);

	    //Find number of rows in excel file
	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	    
		  //get the total row count in the excel sheet	
	      for (int i = 1; i <= rowCount; i++) 
	      {
	    	  Util.println("\nReading " + Constants.FILE_NAME_READ_EXCEL + " row: " + i);
	    	  customerList = new ArrayList<String>(Arrays.asList( "add/edit", Constants.EMPTY_STRING, "halo1234", Constants.EMPTY_STRING, "True", Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING) );
	    	  
	    	  cellValue = new ArrayList<String>();
	    	  
	        // get the total cell count in the excel sheet
	            int cellcount = sheet.getRow(i).getLastCellNum();
	            for (int j = 0; j < cellcount; j++) 
	            {                         
	            	if(j==1 || j==2 || j==3 || j==4 || j==5 || j==7 || j == 12 || j == 18) {
		                if(sheet.getRow(i).getCell(j) != null) {
//		                	System.out.print("(i= " + i + " j= "+ j + ") " + sheet.getRow(i).getCell(j).toString() +" || ");
		                	cellValue.add(sheet.getRow(i).getCell(j).toString().trim());
		                }else {
//		                	System.out.print("(i= " + i + " j= "+ j + ") " + EMPTY_STRING +" || ");
		                	cellValue.add(Constants.EMPTY_STRING);
		                }
	            	}
	            }	
	            
	            //************** Customers sheet *************//
	            
            	customerList.set(1, cellValue.get(0)); //Add element at 1 index (EMP ID)
            	customerList.set(5, Util.getReadableShopperGroup(cellValue.get(4))); //Add element at 5 index (Shopper Group)
            	customerList.set(6, cellValue.get(1)); //Add element at 6 index (FNAME)
            	customerList.set(8, cellValue.get(2)); //Add element at 8 index (LNAME)
            	customerList.set(9, cellValue.get(0)); //Add element at 9 index (EMP ID)
            	customerList.set(12, Util.getLocalDate(Constants.DATE_FORMATE2)); //Add element at 12 index (Current Today Date)	 
            	customerList.set(13, cellValue.get(3)); //Add element at 13 index (EMAIL)
            	
//            	for(int k = 0; k < customerList.size(); k++) 
//            	{
//            		System.out.println("\tReading Column " + (k+1) + " with: " + customerList.get(k));
//            	}
//            	System.out.println(customerList);
            	
//            	System.out.println();
            	
            	// write to excel code here
            	try {
            		//************** Customers sheet *************//
            		String FILE_NAME_WRITE_EXCEL = "";
            		if(Constants.IS_XLS_FILE) {
            			FILE_NAME_WRITE_EXCEL = Constants.FILE_NAME_WRITE_EXCEL_XLS;
            		}else {
            			FILE_NAME_WRITE_EXCEL = Constants.FILE_NAME_WRITE_EXCEL_XLSX;
            		}
            		writeExcelCustomers(Constants.FILE_PATH_EXCEL, FILE_NAME_WRITE_EXCEL, Constants.FILE_SHEET_NAME_WRITE_EXCEL_CUSTOMERS, customerList, i);
				} catch (Exception e) {
					e.printStackTrace();
					String STRING1 = "\nException occured while writing Customers sheet in excel and detailed message due to: " + e.getLocalizedMessage();
					SendMailSSLWithMessage.sendEmailWithMessage(STRING1);					
					break;
				}
            	
            	for (int propItem = 0; propItem < propName.length; propItem++) {
//        		  System.out.println(propName[propItem]);
                	//************** Properties sheet *************//
            		propertiesList = new ArrayList<String>(Arrays.asList( Constants.EMPTY_STRING, Constants.EMPTY_STRING, Constants.EMPTY_STRING));
                	//Add element at 0 index (Login Name)
                	propertiesList.set(0, cellValue.get(0));
                	//Add element at 1 index (Prop Name)
                	propertiesList.set(1, propName[propItem]);
                	//Add element at 2 index (Prop Value)
                	if(propItem == 0 || propItem == 1) {
                    	propertiesList.set(2, "no"); 
                	}else if(propItem == 2) {
                		propertiesList.set(2, cellValue.get(7)); 
                	}else if(propItem == 3) {
                		propertiesList.set(2, Util.getDOB(cellValue.get(5))); // String date to required DOB format
                	}else if(propItem == 4) {
                		propertiesList.set(2, Util.getLocalDate(Constants.DATE_FORMATE1)); 
                	}else if(propItem == 5) {
                		propertiesList.set(2, "PA"); // cellValue.get(6) - Due to unavailability of Province set US but now hard code with PA
                	}
                	
//                	System.out.println(propertiesList);
                	
                	try {
                		//************** Properties sheet *************//
                		String FILE_NAME_WRITE_EXCEL = "";
                		if(Constants.IS_XLS_FILE) {
                			FILE_NAME_WRITE_EXCEL = Constants.FILE_NAME_WRITE_EXCEL_XLS;
                		}else {
                			FILE_NAME_WRITE_EXCEL = Constants.FILE_NAME_WRITE_EXCEL_XLSX;
                		}
                		writeExcelProperties(Constants.FILE_PATH_EXCEL, FILE_NAME_WRITE_EXCEL, Constants.FILE_SHEET_NAME_WRITE_EXCEL_PROPERTIES, propertiesList, (propItem + 1));
    				} catch (Exception e) {
    					e.printStackTrace();
    					String STRING1 = "\nException occured while writing Properties sheet in excel and detailed message due to: " + e.getLocalizedMessage();
    					SendMailSSLWithMessage.sendEmailWithMessage(STRING1);
    					break;
    				}
        		}
            	
	       }

	       //Close input stream
	    	inputStream.close();
	    	
	      System.out.println("Excel conversion completed");
	      System.out.println("\n*****************************************************************************");	      
	      System.out.println("Finished with total records: " + rowCount);
	      System.out.println("*****************************************************************************");
	      SendMailSSLWithMessage.sendEmailWithMessage("Finished with total records: " + rowCount);
	} 
	
	/*
	 * writeExcelCustomers function to read data from FILE_NAME_WRITE_EXCEL into FILE_SHEET_NAME_WRITE_EXCEL_CUSTOMERS sheet
	 */
	public void writeExcelCustomers(String filePath,String fileName,String sheetName,ArrayList<String> dataToWrite,int rowCount) throws IOException{
		
		Util.println("\n\tWriting into Customer sheet in " + fileName + " file on row: " + rowCount);

        //Create an object of File class to open xlsx file
        File file =    new File(filePath+"//"+fileName);
        //Create an object of FileInputStream class to read excel file
        FileInputStream inputStream = new FileInputStream(file);
        
        if(Constants.IS_XLS_FILE) {
        	writeWorkbook = new HSSFWorkbook(inputStream); // for ".xls" file
        }else {
        	writeWorkbook = new XSSFWorkbook(inputStream); // for ".xlsx" file
        }
  
	    //Read excel sheet by sheet name    
	    Sheet sheet = writeWorkbook.getSheet(sheetName);
	    
	    //Get the first row from the sheet
	    Row row = sheet.getRow(0);
	    
	    //Get the current count of rows in excel file
//	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	    
	    //Create a new row and append it at last of sheet
//	    Row newRow = sheet.createRow(rowCount+1);
	    
	    Row newRow = sheet.createRow(rowCount);
	
	    //Create a loop over the cell of newly created Row
	    for(int j = 0; j < row.getLastCellNum(); j++){
	    	String columnInputValue = dataToWrite.get(j).trim();
//	    	System.out.println("\tWriting Column " + (j+1) + " with: " + columnInputValue);
	        //Fill data in row
	        Cell cell = null;
	        if(j == 1 || j == 9) { // EMP ID - Login Name & Address Nick Name
	        	cell = newRow.createCell(j,CellType.NUMERIC);
	        	cell.setCellValue(Double.parseDouble(columnInputValue));
	        }else {
	        	cell = newRow.createCell(j,CellType.STRING);
	        	cell.setCellValue(columnInputValue);
	        }
	    }
	
	    //Close input stream
	    inputStream.close();
	    
	    //Create an object of FileOutputStream class to create write data in excel file
	    FileOutputStream outputStream = new FileOutputStream(file);
	
	    //write data in the excel file
	    writeWorkbook.write(outputStream);
	    //close output stream
	    outputStream.close();
    }
	
	/*
	 * writeExcelProperties function to read data from FILE_NAME_WRITE_EXCEL into FILE_SHEET_NAME_WRITE_EXCEL_PROPERTIES sheet
	 */	
	public void writeExcelProperties(String filePath,String fileName,String sheetName,ArrayList<String> dataToWrite,int rowCountProperties) throws IOException{
		
		Util.println("\n\t\tWriting into Properties sheet in " + fileName + " file on row: " + rowCountProperties);

        //Create an object of File class to open xlsx file
        File file =    new File(filePath+"//"+fileName);
        //Create an object of FileInputStream class to read excel file
        FileInputStream inputStream = new FileInputStream(file);
        
        if(Constants.IS_XLS_FILE) {
        	writeWorkbook = new HSSFWorkbook(inputStream); // for ".xls" file
        }else {
        	writeWorkbook = new XSSFWorkbook(inputStream); // for ".xlsx" file
        }
  
	    //Read excel sheet by sheet name    
	    Sheet sheet = writeWorkbook.getSheet(sheetName);
	    
	    //Get the first row from the sheet
	    Row row = sheet.getRow(0);
	    
	    //Get the current count of rows in excel file
	    int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
	    
	    //Create a new row and append it at last of sheet
	    Row newRow = sheet.createRow(rowCount+1);
	    
//	    Row newRow = sheet.createRow(0);
	
	    //Create a loop over the cell of newly created Row
	    for(int j = 0; j < row.getLastCellNum(); j++){
	    	String columnInputValue = dataToWrite.get(j).trim();
//	    	System.out.println("\tWriting Column " + (j+1) + " with: " + columnInputValue);
	        //Fill data in row
	        Cell cell = null;
	        if(j == 0) { // EMP ID - Login Name
	        	cell = newRow.createCell(j,CellType.NUMERIC);
	        	cell.setCellValue(Double.parseDouble(columnInputValue));
	        }else {
	        	cell = newRow.createCell(j,CellType.STRING);
	        	cell.setCellValue(columnInputValue);
	        }
	    }
	
	    //Close input stream
	    inputStream.close();
	    
	    //Create an object of FileOutputStream class to create write data in excel file
	    FileOutputStream outputStream = new FileOutputStream(file);
	
	    //write data in the excel file
	    writeWorkbook.write(outputStream);
	    //close output stream
	    outputStream.close();
    }
	
	/*
	 * deleteRowsExcel function to delete rows into passed sheetName1 & sheetName2
	 */	
	public void deleteRowsExcel(String filePath,String fileName,String sheetName1,String sheetName2) throws IOException{
		System.out.println("\nDeleting rows from " + sheetName1 + " and " + sheetName2 );

        //Create an object of File class to open xlsx file
        File file =    new File(filePath+"//"+fileName);
        //Create an object of FileInputStream class to read excel file
        FileInputStream inputStream = new FileInputStream(file);
        
        if(Constants.IS_XLS_FILE) {
        	writeWorkbook = new HSSFWorkbook(inputStream); // for ".xls" file
        }else {
        	writeWorkbook = new XSSFWorkbook(inputStream); // for ".xlsx" file
        }
        
	    //Read excel sheet by sheet name Customers  
	    Sheet sheetCustomers = writeWorkbook.getSheet(sheetName1);
	    
	    int lastRowNumCustomers = sheetCustomers.getLastRowNum();
	    for(int i=1; i<= lastRowNumCustomers; i++){
            Row row = sheetCustomers.getRow(i);
            Util.deleteRow(sheetCustomers, row);
        }
	    
	    System.out.println("\tTotal record deleted in " + sheetName1 + " : " + lastRowNumCustomers);
	    
	    //Read excel sheet by sheet name Properties
	    Sheet sheetProperties = writeWorkbook.getSheet(sheetName2);
	    
	    int lastRowNumProperties = sheetProperties.getLastRowNum();
	    for(int i=1; i<= lastRowNumProperties; i++){
            Row row = sheetProperties.getRow(i);
            Util.deleteRow(sheetProperties, row);
        }
	    System.out.println("\tTotal record deleted in " + sheetName2 + " : " + lastRowNumProperties);
	    
	    //Close input stream
	    inputStream.close();
	    
	    //Create an object of FileOutputStream class to create write data in excel file
	    FileOutputStream outputStream = new FileOutputStream(file);
	
	    //write data in the excel file
	    writeWorkbook.write(outputStream);
	    //close output stream
	    outputStream.close();
        
	}
	
	/*
	 * Main function is calling 'readExcel' function to read data from excel file and 'writeExcel' function to write data into excel file
	 */
    public static void main( String[] args )
    {
    	String projectRootPath = Util.getProjectDirectory();
		String fileWithPathOS = "";
		if(Util.isWindows()) {
			fileWithPathOS = projectRootPath + "\\" +  Constants.FILE_PATH_EXCEL+"\\"+Constants.FILE_NAME_READ_EXCEL;
			System.out.println(fileWithPathOS);
		}else {
			fileWithPathOS = projectRootPath + "/" +  Constants.FILE_PATH_EXCEL+"/"+Constants.FILE_NAME_READ_EXCEL; 
			System.out.println(fileWithPathOS);
		}

    	// String fileWithPath = Constants.FILE_PATH_EXCEL+"//"+Constants.FILE_NAME_READ_EXCEL;
    	// System.out.println(fileWithPath);
    	// To get file is exist or not
    	if(Util.isFileExist(fileWithPathOS)) {
    		
	    	AppExcelData appExcelData = new AppExcelData();
	    	
	    	String strProgramStarted = "WAWA TVR program has stared.";
	    	System.out.println(strProgramStarted);
	    	SendMailSSLWithMessage.sendEmailWithMessage(strProgramStarted);
	    	
	    	System.out.println("Excel conversion started.");
	    	
	    	java.util.Date startDateTime = Util.getDateTime(); // to get datetime when script started
	    	
	    	// to fille shopper group list hard coded with hashmap - key value pair
	    	Util.fillShopperGroupList();
	    	
	    	// Deleting all rows except heading from excel file for sheets FILE_SHEET_NAME_WRITE_EXCEL_CUSTOMERS and FILE_SHEET_NAME_WRITE_EXCEL_PROPERTIES
	    	try {
	    		String FILE_NAME_WRITE_EXCEL = "";
	    		if(Constants.IS_XLS_FILE) {
	    			FILE_NAME_WRITE_EXCEL = Constants.FILE_NAME_WRITE_EXCEL_XLS;
	    		}else {
	    			FILE_NAME_WRITE_EXCEL = Constants.FILE_NAME_WRITE_EXCEL_XLSX;
	    		}
	    		// Delete all rows except heading into excel by passed sheets
	    		appExcelData.deleteRowsExcel(Constants.FILE_PATH_EXCEL, FILE_NAME_WRITE_EXCEL, Constants.FILE_SHEET_NAME_WRITE_EXCEL_CUSTOMERS, Constants.FILE_SHEET_NAME_WRITE_EXCEL_PROPERTIES);
	    		
			} catch (Exception e) {
				e.printStackTrace();
				String STRING1 = "\nException occured while deleting excel rows and detailed message due to: " + e.getLocalizedMessage();
				SendMailSSLWithMessage.sendEmailWithMessage(STRING1);
			}	
	
	    	// Reading excel file
	    	try {
	    		
	    		//Call read file method of the class to read data
	    		appExcelData.readExcel(Constants.FILE_PATH_EXCEL, Constants.FILE_NAME_READ_EXCEL, Constants.FILE_SHEET_INDEX_READ_EXCEL);
			} catch (Exception e) {
				e.printStackTrace();
				String STRING1 = "\nException occured while read & write excel and detailed message due to: " + e.getLocalizedMessage();
				SendMailSSLWithMessage.sendEmailWithMessage(STRING1);
			}
	    	
	    	java.util.Date endDateTime = Util.getDateTime(); // to get datetime when script ended
	    	System.out.println("Excel conversion time taken:");
	    	Util.showTimeDifference(startDateTime, endDateTime);
	    	
		    try {
		    	System.out.println("\nWait for 2 second before Customer.xls file upload to ShopSTAR\n");
		        Thread.sleep(2000);
		      } catch (InterruptedException e) {
		        e.printStackTrace();
		      }		
	    	
	    	String strExcelConversionMsg = "Excel conversion has done with following total time taken. Now program will start for uploading to shop star.\n";
	    	String strtimeDifferenceInString = Util.showTimeDifferenceInString(startDateTime, endDateTime, strExcelConversionMsg);
	    	SendMailSSLWithMessage.sendEmailWithMessage(strtimeDifferenceInString);
	    	
	    	java.util.Date startDateTimeUploadCustomer = Util.getDateTime(); 
		    
	    	// Upload Customer.xls file to ShopSTAR using selenium 
	    	UploadCustomerData uploadCustomerData = new UploadCustomerData();
	    	uploadCustomerData.processData();
	    	
	    	java.util.Date endDateTimeUploadCustomer = Util.getDateTime(); 
	    	
	    	String strCustomerUploadMsg = "Customer upload completed and total time taken:\n";
	    	String strtimeDifferenceInStringCustomerUpload = Util.showTimeDifferenceInString(startDateTimeUploadCustomer, endDateTimeUploadCustomer, strCustomerUploadMsg);
	    	SendMailSSLWithMessage.sendEmailWithMessage(strtimeDifferenceInStringCustomerUpload);
	    	
	    	java.util.Date endDateTimeCompleted = Util.getDateTime(); 
	    	String strCompleteMsg = "WAWA TVR Script run completed and total time taken:\n";
	    	String strtimeDifferenceInStringCompleted = Util.showTimeDifferenceInString(startDateTime, endDateTimeCompleted, strCompleteMsg);
	    	SendMailSSLWithMessage.sendEmailWithMessage(strtimeDifferenceInStringCompleted);


			  try {
		    	System.out.println("\nWait for 5 second before delete WAW9_TVRdata.xlsx\n");
		        Thread.sleep(5000);

		        // To delete file WAW9_TVRdata.xlsx after Customer upload successfully
				Util.deleteFile(fileWithPathOS);

				System.out.println("\nWait for 5 second after delete WAW9_TVRdata.xlsx\n");
		        Thread.sleep(5000);
		      } catch (InterruptedException e) {
		        e.printStackTrace();
		      }	
    	
    	}else {
    		System.out.println(Constants.FILE_NAME_READ_EXCEL + " not exist please place this file before start script.");
    		try {
		    	System.out.println("\nWait for 5 second before Close program\n");
		        Thread.sleep(5000);
		      } catch (InterruptedException e) {
		        e.printStackTrace();
		      }	
    		
    	}
    }
}
