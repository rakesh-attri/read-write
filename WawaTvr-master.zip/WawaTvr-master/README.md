# WawaTvr

This project related to WawaTVR file data to required shopSTAR template through Automation.